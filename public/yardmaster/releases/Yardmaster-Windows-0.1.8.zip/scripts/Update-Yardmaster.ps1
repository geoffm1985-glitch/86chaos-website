param(
  [string]$ManifestUrl='https://www.86chaos.com/yardmaster/release.json',
  [string]$PackagePath='',
  [switch]$NoLaunch
)
$ErrorActionPreference='Stop'
$Root=Join-Path $env:LOCALAPPDATA 'Yardmaster'
$AppRoot=Join-Path $Root 'app'
$TempRoot=Join-Path $env:TEMP ('Yardmaster-Update-'+[guid]::NewGuid().ToString('N'))
$Archive=if($PackagePath){$PackagePath}else{Join-Path $TempRoot 'Yardmaster-Windows.zip'}

function Stop-YardmasterAppProcesses {
  Get-Process -Name electron -ErrorAction SilentlyContinue | Where-Object {
    try { [string]$_.Path -like "$AppRoot*" } catch { $false }
  } | ForEach-Object { try { & taskkill.exe /PID $_.Id /T /F | Out-Null } catch {} }
  Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $cmd=[string]$_.CommandLine
    $exe=[string]$_.ExecutablePath
    (($_.Name -eq 'node.exe') -and $cmd -like "*$AppRoot*" -and $cmd -like '*server.mjs*') -or
    (($_.Name -eq 'electron.exe') -and ($cmd -like "*$AppRoot*" -or $exe -like "$AppRoot*")) -or
    (($_.Name -eq 'msedge.exe') -and $cmd -like '*Yardmaster\edge-profile*')
  } | ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop } catch {} }
}

function Set-YardmasterRegistration {
  param([string]$Version)
  $electron=Join-Path $AppRoot 'node_modules\electron\dist\electron.exe'
  $desktopEntry=Join-Path $AppRoot 'desktop.cjs'
  $icon=Join-Path $AppRoot 'public\yardmaster-icon.ico'
  $uninstallScript=Join-Path $AppRoot 'scripts\Uninstall-Yardmaster.ps1'
  $uninstallKey='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Yardmaster'
  $uninstallCommand='powershell.exe -NoProfile -ExecutionPolicy Bypass -File "'+$uninstallScript+'"'
  New-Item -Path $uninstallKey -Force | Out-Null
  foreach($item in @{
    DisplayName='Yardmaster';DisplayVersion=$Version;Publisher='Chilton App Works LLC';InstallLocation=$AppRoot;
    DisplayIcon=$icon;UninstallString=$uninstallCommand;QuietUninstallString=($uninstallCommand+' -Quiet')
  }.GetEnumerator()){New-ItemProperty -Path $uninstallKey -Name $item.Key -Value ([string]$item.Value) -PropertyType String -Force | Out-Null}
  New-ItemProperty -Path $uninstallKey -Name NoModify -Value 1 -PropertyType DWord -Force | Out-Null
  New-ItemProperty -Path $uninstallKey -Name NoRepair -Value 1 -PropertyType DWord -Force | Out-Null
  $desktop=[Environment]::GetFolderPath('Desktop')
  $startMenu=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
  $shell=New-Object -ComObject WScript.Shell
  foreach($dest in @((Join-Path $desktop 'Yardmaster.lnk'),(Join-Path $startMenu 'Yardmaster.lnk'))){
    $sc=$shell.CreateShortcut($dest);$sc.TargetPath=$electron;$sc.Arguments='"'+$desktopEntry+'"';$sc.WorkingDirectory=$AppRoot;$sc.IconLocation=$icon+',0';$sc.Save()
  }
}

New-Item -ItemType Directory -Force -Path $TempRoot | Out-Null
try {
  $manifest=$null
  if(-not $PackagePath){
    $manifest=Invoke-RestMethod -Uri $ManifestUrl -Method Get -TimeoutSec 30
    if($manifest.verified -ne $true -or -not $manifest.version -or -not $manifest.downloadUrl -or -not $manifest.sha256){throw 'Yardmaster release manifest is incomplete or not verified.'}
    $downloadUri=[Uri]::new([Uri]$ManifestUrl,[string]$manifest.downloadUrl).AbsoluteUri
    Invoke-WebRequest -Uri $downloadUri -OutFile $Archive -UseBasicParsing -TimeoutSec 120
    $actual=(Get-FileHash -LiteralPath $Archive -Algorithm SHA256).Hash.ToLowerInvariant()
    if($actual -ne ([string]$manifest.sha256).ToLowerInvariant()){throw 'Yardmaster update checksum verification failed. No files were changed.'}
  }
  if(-not(Test-Path -LiteralPath $Archive)){throw 'Yardmaster update package was not found.'}
  $Extracted=Join-Path $TempRoot 'package';New-Item -ItemType Directory -Force -Path $Extracted | Out-Null
  Expand-Archive -LiteralPath $Archive -DestinationPath $Extracted -Force
  $pkgFile=Get-ChildItem -LiteralPath $Extracted -Recurse -File -Filter package.json | Where-Object { Test-Path (Join-Path $_.Directory.FullName 'scripts\Install-Yardmaster.ps1') } | Select-Object -First 1
  if(-not $pkgFile){throw 'The verified Yardmaster package is incomplete.'}
  $source=$pkgFile.Directory.FullName
  $incoming=Get-Content (Join-Path $source 'package.json') -Raw | ConvertFrom-Json
  if($manifest -and [string]$incoming.version -ne [string]$manifest.version){throw 'The package version does not match the verified release manifest.'}

  Stop-YardmasterAppProcesses
  Start-Sleep -Milliseconds 800
  New-Item -ItemType Directory -Force -Path $AppRoot | Out-Null
  robocopy $source $AppRoot /MIR /XD .git node_modules bin /XF *.log | Out-Null
  if($LASTEXITCODE -ge 8){throw "Yardmaster update copy failed with code $LASTEXITCODE"}
  Push-Location $AppRoot
  try {
    npm install --omit=dev --no-audit --no-fund
    if($LASTEXITCODE -ne 0){throw 'Yardmaster dependency update failed.'}
  } finally { Pop-Location }
  $electron=Join-Path $AppRoot 'node_modules\electron\dist\electron.exe'
  if(-not(Test-Path $electron)){throw 'Electron runtime is missing after the update.'}
  Set-YardmasterRegistration -Version ([string]$incoming.version)
  if(-not $NoLaunch){& (Join-Path $AppRoot 'scripts\Start-Yardmaster.ps1')}
} finally {
  Remove-Item -LiteralPath $TempRoot -Recurse -Force -ErrorAction SilentlyContinue
}
