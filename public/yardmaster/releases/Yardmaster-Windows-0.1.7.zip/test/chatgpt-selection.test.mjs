import test from 'node:test';
import assert from 'node:assert/strict';
import {__testHooks} from '../automation/chatgpt.mjs';

function selectorCdp({after={mode:'Work',model:'GPT-5.6 Sol',thinking:'High'},stuck=false}={}){
  const calls=[];const reads={mode:0,model:0,thinking:0};
  return {
    calls,reads,
    async eval(expression){
      calls.push(expression);
      const match=expression.match(/YM_READ_CONTROL:(model|mode|thinking)/);
      if(match){
        const kind=match[1],read=reads[kind]++;
        const before={mode:'Chat',model:'GPT-5.6 Terra',thinking:'Medium'}[kind];
        return {label:stuck||read===0?before:after[kind],fingerprint:{testid:'composer-'+kind,index:0},score:12};
      }
      if(/YM_OPEN_CONTROL/.test(expression)||/YM_PICK_OPTION/.test(expression)||/YM_CLOSE_CONTROL/.test(expression))return true;
      return null;
    }
  };
}

test('ChatGPT mode, model, and thinking use composer controls and verified read-back',async()=>{
  const cdp=selectorCdp();const statuses=[];
  const configured=await __testHooks.chooseModeAndModel(cdp,'Work','GPT-5.6 Sol',message=>statuses.push(message));
  assert.equal(configured,true,statuses.join(' | ')+' | reads='+JSON.stringify(cdp.reads));
  assert.equal(await __testHooks.chooseThinkingEffort(cdp,'High',message=>statuses.push(message)),true);
  const markers=cdp.calls.map(value=>(value.match(/YM_(?:READ|OPEN|PICK|CLOSE)_CONTROL(?::(model|mode|thinking))?/)||[])[0]).filter(Boolean);
  assert.ok(markers.some(value=>value.includes('READ_CONTROL:mode')));
  assert.ok(markers.some(value=>value.includes('READ_CONTROL:model')));
  assert.ok(markers.some(value=>value.includes('READ_CONTROL:thinking')));
  assert.ok(statuses.includes('Verified ChatGPT mode: Work'));
  assert.ok(statuses.includes('Verified ChatGPT model: GPT-5.6 Sol'));
  assert.ok(statuses.includes('Verified ChatGPT thinking effort: High'));
});

test('ChatGPT selector fails closed when the same control does not report the requested value',async()=>{
  const cdp=selectorCdp({stuck:true});const statuses=[];
  assert.equal(await __testHooks.chooseThinkingEffort(cdp,'High',message=>statuses.push(message)),false);
  assert.match(statuses.at(-1),/could not verify/i);
});

test('ChatGPT selector rejects unrelated visible text when no composer control is found',async()=>{
  const cdp={eval:async expression=>/YM_READ_CONTROL/.test(expression)?null:true};
  assert.equal(await __testHooks.chooseModeAndModel(cdp,'Work','GPT-5.6 Sol'),false);
});

test('usage-limit detection captures reset detail without buying usage',async()=>{
  const cdp={eval:async()=>"You've reached the Work usage limit. Your access resets at 3:00 PM."};
  const result=await __testHooks.usageLimitInfo(cdp);
  assert.equal(result.limited,true);
  assert.match(result.detail,/resets at 3:00 PM/i);
});
